
# Projeto Temático em Aplicações Web

Repositório de código e documentos para o grupo 4.


## Tech Stack

**Client:** HTML, CSS, JS

**Server:** SQL


## Authors

- [Tomás Rosa](https://github.com/TomasRosaDev) 
- [João Coelho](https://github.com/draganoid16) 
- [Gonçalo Gonçalves](https://github.com/GoncaloGoncalves33) 
- [Gonçalo Dias](https://github.com/gjad-hub) 
