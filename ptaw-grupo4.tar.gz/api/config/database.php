<?php

class database {
    private $host = "localhost";
    private $user = "ptaw-2023-gr4";
    private $pwd = "qj+5pg!D9;k?*Kpm";
    private $db = "ptaw-2023-gr4";
    
    public function connect(){
        $str = "pgsql:host=$this->host; port=5432; dbname=$this->db";
        $conn = new PDO($str, $this->user, $this->pwd);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $conn;
    }
}
