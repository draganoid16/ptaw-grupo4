# Security Policy

### Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 3.x.x   | :white_check_mark: |
| 4.x.x   | :white_check_mark: |


### Reporting a Vulnerability

To report a vulnerability please send an email to security@slimframework.com
